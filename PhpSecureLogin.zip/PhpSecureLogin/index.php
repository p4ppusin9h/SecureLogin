
<?php
$error = false;
error_reporting (0);
$conn = mysqli_connect("localhost", "root", "", "user");
session_start();
if (isset($_POST['login']))
{
    $usernm = mysqli_real_escape_string($conn, $_POST['username']);
    $userpass = mysqli_real_escape_string($conn, $_POST['password']); 
    $userpassMd5 = md5($userpass); 
    $sql = "SELECT * FROM userinfo WHERE username = '$usernm' && password = '$userpassMd5' ";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_num_rows($result);

    if ($data==1)
    {
        $_SESSION['admin_name'] = $usernm;
        header('location:home.php');
    }
    else 
    {
        $error = true;
    }
}
?> 

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<h2> Secure Login Pannel</h2>
<form action="" method="POST">
    <label>User Name</label>
    <input type="text" name="username" class="form-control"  placeholder="Enter Username" required=""> <br> <br>
    <label>Password</label>
    <input type="password" name="password" class="form-control" placeholder="Enter Password" required=""> <br> <br>
    <input type="submit" name="login" value="Login">

  <?php 
      if ($error)
      {
        echo "<p> Invalid Username Or Password </p>";
      }

    ?> 
 </form>
</body>

</html>
