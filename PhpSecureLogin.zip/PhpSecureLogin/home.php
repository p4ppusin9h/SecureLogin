<?php 
session_start();
$admin = $_SESSION['admin_name'];
if ($admin)
{
   
}
else
{
  header('location:index.php');
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>This is Homepage</h2>
<a href="logout.php">Logout</a>
</body>
</html>